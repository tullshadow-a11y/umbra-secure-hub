# Breeze Inbox Buddy

Build a modern, fully functional temporary email web application with a sleek dark glassmorphism UI using Tailwind CSS. 

Key features:

1. Instantly generate a random temporary email address with a one-click copy button.

2. A clean live inbox section that displays incoming messages (Sender, Subject, Time, and Body content) dynamically.

3. Action buttons to refresh the inbox, delete the current email, or generate a new random address.

4. Professional empty states when no messages are present, ensuring a clean and production-ready look with no fake placeholder data.

## Development

You need Node.js and npm (or Bun).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
